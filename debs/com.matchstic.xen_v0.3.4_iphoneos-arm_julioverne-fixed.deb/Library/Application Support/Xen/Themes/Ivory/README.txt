When creating your own themes, it's simply a matter of creating new versions of the .png's in here, and dropping them into your theme. If an image isn't themed, then it will default an image built at runtime for the BLUR theme. 

With the folders, the images in there can also be themed. Just create the relevant folder in your theme, and drop the new images into it.

For changing the current theme, go to Settings > Xen > Additional Features > Theming