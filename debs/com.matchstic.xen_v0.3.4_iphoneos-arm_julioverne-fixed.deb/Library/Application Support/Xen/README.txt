Hello, friend! Making a new theme for Xen?

I’d recommend using the Ivory theme as a base for what images you can customise. I’ve included a couple of READMEs in there too, but make sure to check the first post at: http://modmyi.com/forums/iphone-6-themes-launches/850118-xen-supercharge-your-lockscreen.html for the most up-to-date information about theming Xen.