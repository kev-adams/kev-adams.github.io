These are the images displayed when a new notification comes in. For any given app, the name of it's icon must be the same as it's bundle ID - use AppInfo to get this if necessary.

Additional icons can be included within your theme, so if you have say "com.apple.Reminders@2x.png" in your theme, that'll be used even if it's not present here.